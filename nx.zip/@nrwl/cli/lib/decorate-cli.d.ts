export * from 'nx/src/adapter/decorate-cli';
