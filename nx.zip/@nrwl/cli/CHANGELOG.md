# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [14.5.10](https://github.com/nrwl/nx/compare/14.5.8...14.5.10) (2022-08-23)

**Note:** Version bump only for package @nrwl/cli
